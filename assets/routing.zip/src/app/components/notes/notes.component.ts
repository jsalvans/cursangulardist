import { Component } from '@angular/core';

@Component({
  selector: 'app-notes',
  template: `
<div>
  <table border="1">
    <tr>
      <th>ID</th>
      <th>Name</th>
    </tr>
    <tr *ngFor="let n of notes">
      <td><a [routerLink]="['/note', n.id]">{{n.id}}</a></td>
      <td>{{n.name}}</td>
    </tr>
  </table>
</div>
`
})
export class NotesComponent {

  notes = [{
    id: 1,
    name: 'Note 1'
  }, {
    id: 2,
    name: 'Note 2'
  }, {
    id: 3,
    name: 'Note 3'
  }];

}