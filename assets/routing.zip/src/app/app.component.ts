import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuardService } from './services/auth-guard.service';

@Component({
  selector: 'app-root',
  template: `
<div *ngIf="this.router.url !== '/login'">
  <a routerLink="welcome" routerLinkActive="activated">Welcome</a> | 
  <a routerLink="notes" routerLinkActive="activated">Notes</a> | 
  <a href="#" (click)="logout()">Log out</a>
  <br />
</div>
<router-outlet></router-outlet>
`,
  styles: ['.activated { font-weight: bold; }']
})
export class AppComponent {

  constructor(public router: Router,
    public authService: AuthGuardService) { }

  logout() {
    this.authService.user = null;
    this.router.navigate(['/login']);
  }

}
