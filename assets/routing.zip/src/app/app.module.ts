import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { NotesComponent } from './components/notes/notes.component';
import { NoteComponent } from './components/note/note.component';
import { WelcomeComponent } from './components/welcome/welcome.component';

import { AuthGuardService } from './services/auth-guard.service';

const routes: Routes = [
  { path: 'login',    component: LoginComponent },
  { path: 'welcome',  component: WelcomeComponent, canActivate: [AuthGuardService] },
  { path: 'notes',    component: NotesComponent,   canActivate: [AuthGuardService] },
  { path: 'note/:id', component: NoteComponent,    canActivate: [AuthGuardService] },
  { path: '**',       redirectTo: 'notes' }
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NotesComponent,
    NoteComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes, {useHash: true})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
