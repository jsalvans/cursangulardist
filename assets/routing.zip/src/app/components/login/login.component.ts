import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuardService } from '../../services/auth-guard.service';

@Component({
  selector: 'app-login',
  template: `
<div>
  Username: <input [(ngModel)]="username" /><br />
  Password: <input [(ngModel)]="password" type="password" /><br />
  <button (click)="login()">Login</button>
</div>
`
})
export class LoginComponent {

  username: string;
  password: string;

  constructor(public router: Router,
    public authService: AuthGuardService) { }

  login() {
    if (this.username === 'admin' && this.password === '1234') {
      this.authService.user = this.username;
      this.router.navigate(['welcome']);
    } else {
      alert('Username or password incorrect.')
    }
  }

}