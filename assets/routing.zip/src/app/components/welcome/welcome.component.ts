import { Component } from '@angular/core';
import { AuthGuardService } from '../../services/auth-guard.service';

@Component({
  selector: 'app-welcome',
  template: '<div>Welcome {{authService.user}}!</div>'
})
export class WelcomeComponent {

  constructor(public authService: AuthGuardService) { }

}
