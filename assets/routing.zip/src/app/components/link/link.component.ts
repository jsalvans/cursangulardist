import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-link',
  template: `
  <style>a { color: blue; } .activated { font-weight: bold; }</style>
  <a routerLink="/link" routerLinkActive="activated">Link</a>
  <br/>
  <a routerLink="/link" routerLinkActive="activated" [routerLinkActiveOptions]="{exact: true}">Link Exact</a>
  <br/>
  <div routerLinkActive="activated">
    <a routerLink="/link/1">Link 1</a>
  </div>
  <a routerLink="/link/2" routerLinkActive="activated">Link 2</a>
`,
})
export class LinkComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
